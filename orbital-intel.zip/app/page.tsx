"use client";

import { useEffect, useMemo, useState } from "react";

type Cabin = "ECONOMY" | "PREMIUM_ECONOMY" | "BUSINESS";
type HubCode = "LIS" | "MAD" | "BCN" | "CDG" | "AMS" | "MXP" | "FCO" | "IST";

const HUBS: { code: HubCode; label: string }[] = [
  { code: "LIS", label: "Lisbon (LIS)" },
  { code: "MAD", label: "Madrid (MAD)" },
  { code: "BCN", label: "Barcelona (BCN)" },
  { code: "CDG", label: "Paris (CDG)" },
  { code: "AMS", label: "Amsterdam (AMS)" },
  { code: "MXP", label: "Milan (MXP)" },
  { code: "FCO", label: "Rome (FCO)" },
  { code: "IST", label: "Istanbul (IST)" },
];

type Deal = {
  id: string;
  origin: string;
  destination: string;
  departDate: string;
  returnDate?: string;
  price: number;
  currency: string;
  airlineCodes: string[];
  nonstop?: boolean;
  cabin: Cabin;
  rarityScore: number; // 1–100
  tag: "INSANE" | "RARE" | "NORMAL";
  note?: string; // e.g., "ERROR LIKELY"
};

type Vault = {
  amadeusClientId: string;
  amadeusClientSecret: string;
  amadeusEnv: "test" | "prod";
  rareApisJson: string; // freeform for future
};

const VAULT_KEY = "orbitalintel.vault.v1";

function clamp(n: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, n));
}

function formatMoney(amount: number, currency: string) {
  try {
    return new Intl.NumberFormat(undefined, { style: "currency", currency }).format(amount);
  } catch {
    return `${amount.toFixed(2)} ${currency}`;
  }
}

export default function HomePage() {
  const [vaultOpen, setVaultOpen] = useState(false);
  const [vault, setVault] = useState<Vault>({
    amadeusClientId: "",
    amadeusClientSecret: "",
    amadeusEnv: "test",
    rareApisJson: "",
  });

  const [origin, setOrigin] = useState<HubCode>("MAD");
  const [destination, setDestination] = useState<string>("JFK");
  const [cabin, setCabin] = useState<Cabin>("BUSINESS");
  const [departDate, setDepartDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 30);
    return d.toISOString().slice(0, 10);
  });
  const [returnDate, setReturnDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 37);
    return d.toISOString().slice(0, 10);
  });
  const [flexibleDates, setFlexibleDates] = useState<boolean>(true);
  const [insaneOnly, setInsaneOnly] = useState<boolean>(false);

  const [status, setStatus] = useState<string>("Silent.");
  const [loading, setLoading] = useState<boolean>(false);
  const [deals, setDeals] = useState<Deal[]>([]);
  const [lastRun, setLastRun] = useState<string>("—");

  useEffect(() => {
    const saved = localStorage.getItem(VAULT_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as Vault;
        setVault(parsed);
      } catch {}
    } else {
      // encourage Vault setup once
      setVaultOpen(true);
    }
  }, []);

  const activated = useMemo(() => {
    return (vault.amadeusClientId?.trim() && vault.amadeusClientSecret?.trim()) ? true : false;
  }, [vault]);

  const filteredDeals = useMemo(() => {
    const list = insaneOnly ? deals.filter(d => d.tag === "INSANE" || d.note === "ERROR LIKELY") : deals;
    return list.sort((a, b) => a.price - b.price);
  }, [deals, insaneOnly]);

  async function testConnection() {
    setLoading(true);
    setStatus("Testing Amadeus connection…");
    try {
      const res = await fetch("/api/amadeus/token", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          clientId: vault.amadeusClientId,
          clientSecret: vault.amadeusClientSecret,
          env: vault.amadeusEnv,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "Token request failed");
      setStatus("Amadeus online.");
      return true;
    } catch (e: any) {
      setStatus(`Amadeus offline: ${e.message}`);
      return false;
    } finally {
      setLoading(false);
    }
  }

  function saveVault() {
    localStorage.setItem(VAULT_KEY, JSON.stringify(vault));
    setStatus("Vault saved.");
  }

  function resetVault() {
    localStorage.removeItem(VAULT_KEY);
    setVault({
      amadeusClientId: "",
      amadeusClientSecret: "",
      amadeusEnv: "test",
      rareApisJson: "",
    });
    setDeals([]);
    setStatus("Vault reset.");
    setVaultOpen(true);
  }

  function computeRarity(allPrices: number[], price: number) {
    if (allPrices.length < 3) {
      // fallback heuristic
      const score = clamp(Math.round(85 - (price / 100)), 10, 95);
      return { score, tag: score >= 85 ? "INSANE" as const : score >= 70 ? "RARE" as const : "NORMAL" as const };
    }
    const sorted = [...allPrices].sort((a, b) => a - b);
    const median = sorted[Math.floor(sorted.length / 2)];
    const ratio = price / median; // <1 good
    // map ratio to score
    const score = clamp(Math.round(100 - (ratio * 60)), 1, 100);
    const tag = score >= 85 ? "INSANE" : score >= 70 ? "RARE" : "NORMAL";
    return { score, tag: tag as "INSANE" | "RARE" | "NORMAL" };
  }

  function rarityNote(score: number) {
    if (score >= 92) return "ERROR LIKELY";
    return undefined;
  }

  async function scanOnce(scanOrigin: string, scanDestination: string) {
    const res = await fetch("/api/amadeus/flight-offers", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        clientId: vault.amadeusClientId,
        clientSecret: vault.amadeusClientSecret,
        env: vault.amadeusEnv,
        origin: scanOrigin,
        destination: scanDestination,
        departDate,
        returnDate,
        cabin,
        adults: 1,
        max: 20,
        nonStop: false,
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data?.error || "Search failed");
    // map to deals
    const offers = (data?.offers ?? []) as any[];
    const mapped = offers.map((o, idx) => {
      const price = Number(o.total);
      const airlineCodes = (o.airlineCodes ?? []) as string[];
      const nonstop = !!o.nonStop;
      return {
        id: `${scanOrigin}-${scanDestination}-${idx}-${o.id ?? idx}`,
        origin: scanOrigin,
        destination: scanDestination,
        departDate,
        returnDate,
        price,
        currency: o.currency || "EUR",
        airlineCodes,
        nonstop,
        cabin,
        rarityScore: 0,
        tag: "NORMAL" as const,
        note: undefined as string | undefined,
      } satisfies Deal;
    });

    const prices = mapped.map(m => m.price).filter(n => Number.isFinite(n));
    const withRarity = mapped.map(m => {
      const { score, tag } = computeRarity(prices, m.price);
      const note = rarityNote(score);
      return { ...m, rarityScore: score, tag, note };
    });

    return withRarity;
  }

  async function scanStandard() {
    if (!activated) {
      setStatus("Insert Amadeus keys in Vault.");
      setVaultOpen(true);
      return;
    }
    setLoading(true);
    setDeals([]);
    setStatus("Scanning…");
    try {
      const list = await scanOnce(origin, destination.trim().toUpperCase());
      setDeals(list);
      setLastRun(new Date().toLocaleString());
      setStatus(list.length ? "Signal acquired." : "No signals.");
    } catch (e: any) {
      setStatus(`Scan failed: ${e.message}`);
    } finally {
      setLoading(false);
    }
  }

  async function scanPredator() {
    if (!activated) {
      setStatus("Insert Amadeus keys in Vault.");
      setVaultOpen(true);
      return;
    }
    setLoading(true);
    setDeals([]);
    setStatus("Predator sweep across hubs…");
    try {
      const dest = destination.trim().toUpperCase();
      const all: Deal[] = [];
      for (const h of HUBS) {
        // sequential keeps it stable on free tiers and avoids rate limits
        const list = await scanOnce(h.code, dest);
        // take best 5 per hub
        all.push(...list.sort((a, b) => a.price - b.price).slice(0, 5));
      }
      // recompute rarity across all results for better ranking
      const prices = all.map(a => a.price).filter(Number.isFinite);
      const final = all.map(a => {
        const { score, tag } = computeRarity(prices, a.price);
        const note = rarityNote(score);
        return { ...a, rarityScore: score, tag, note };
      });
      setDeals(final);
      setLastRun(new Date().toLocaleString());
      setStatus(final.length ? "Predator sweep complete." : "No signals across hubs.");
    } catch (e: any) {
      setStatus(`Predator failed: ${e.message}`);
    } finally {
      setLoading(false);
    }
  }

  const infoPill = activated ? "ACTIVATED" : "LOCKED";

  return (
    <div className="container">
      <div className="topbar">
        <div>
          <div className="brand">
            <div className="logo" />
            <div>
              <div>ORBITAL&nbsp;INTEL</div>
              <div className="sub">Flight Intelligence System</div>
            </div>
          </div>
        </div>
        <div className="pills">
          <div className="pill"><b>{infoPill}</b></div>
          <div className="pill">LAST RUN: <b>{lastRun}</b></div>
          <div className="pill">STATUS: <b>{status}</b></div>
          <button className="btn" onClick={() => setVaultOpen(true)}>VAULT</button>
        </div>
      </div>

      <div className="grid">
        <div className="card">
          <h2>Flight Parameters</h2>
          <div className="form">
            <div>
              <div className="label">Origin</div>
              <select className="select" value={origin} onChange={(e) => setOrigin(e.target.value as HubCode)}>
                {HUBS.map(h => <option key={h.code} value={h.code}>{h.label}</option>)}
              </select>
            </div>
            <div>
              <div className="label">Destination (IATA)</div>
              <input className="input" value={destination} onChange={(e) => setDestination(e.target.value.toUpperCase())} placeholder="JFK / NRT / GRU" />
            </div>

            <div>
              <div className="label">Cabin</div>
              <select className="select" value={cabin} onChange={(e) => setCabin(e.target.value as Cabin)}>
                <option value="ECONOMY">Economy</option>
                <option value="PREMIUM_ECONOMY">Premium Economy</option>
                <option value="BUSINESS">Business</option>
              </select>
            </div>
            <div>
              <div className="label">Mode</div>
              <div className="row">
                <button className="btn primary" onClick={scanStandard} disabled={loading}>SCAN EARTH</button>
                <button className="btn" onClick={scanPredator} disabled={loading}>PREDATOR SWEEP</button>
                <label className="pill" style={{cursor:"pointer"}}>
                  <input type="checkbox" checked={insaneOnly} onChange={(e) => setInsaneOnly(e.target.checked)} />&nbsp;INSANE ONLY
                </label>
              </div>
            </div>

            <div>
              <div className="label">Depart</div>
              <input className="input" type="date" value={departDate} onChange={(e) => setDepartDate(e.target.value)} />
            </div>
            <div>
              <div className="label">Return</div>
              <input className="input" type="date" value={returnDate} onChange={(e) => setReturnDate(e.target.value)} />
            </div>

            <div className="full">
              <div className="small">
                Predator Sweep scans hubs: LIS, MAD, BCN, CDG, AMS, MXP, FCO, IST (sequential for stability).
                Rarity is relative to the current sweep results (no long-term history yet).
              </div>
            </div>
          </div>

          <div className="hr" />

          <h2>Signals</h2>
          {filteredDeals.length === 0 ? (
            <div className="small">No active deals detected. Trigger a scan.</div>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th>Route</th>
                  <th>Cabin</th>
                  <th>Airline</th>
                  <th>Nonstop</th>
                  <th>Rarity</th>
                  <th className="right">Price</th>
                </tr>
              </thead>
              <tbody>
                {filteredDeals.map((d) => (
                  <tr key={d.id}>
                    <td>
                      <div style={{display:"flex", gap:8, alignItems:"center", flexWrap:"wrap"}}>
                        <span style={{fontFamily:"var(--mono)"}}>{d.origin}→{d.destination}</span>
                        {d.tag === "INSANE" && <span className="tag insane">INSANE</span>}
                        {d.tag === "RARE" && <span className="tag ok">RARE</span>}
                        {d.note && <span className="tag warn">{d.note}</span>}
                      </div>
                      <div className="small">{d.departDate}{d.returnDate ? ` → ${d.returnDate}` : ""}</div>
                    </td>
                    <td style={{fontFamily:"var(--mono)"}}>{d.cabin.replace("_", " ")}</td>
                    <td style={{fontFamily:"var(--mono)"}}>{(d.airlineCodes ?? []).join(", ") || "—"}</td>
                    <td style={{fontFamily:"var(--mono)"}}>{d.nonstop ? "YES" : "NO"}</td>
                    <td style={{fontFamily:"var(--mono)"}}>{d.rarityScore}</td>
                    <td className="right" style={{fontFamily:"var(--mono)"}}>{formatMoney(d.price, d.currency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="card">
          <h2>Execution</h2>
          <div className="small">
            ORBITAL INTEL runs silent. It only surfaces anomalies.  
            <br /><br />
            <span className="kbd">INSANE</span> ≈ extreme deviation inside the current sweep.  
            <br />
            <span className="kbd">ERROR LIKELY</span> ≈ very high rarity (buy fast, assume it can be corrected).
          </div>

          <div className="hr" />

          <h2>Controls</h2>
          <div className="row">
            <button className="btn" onClick={() => setVaultOpen(true)}>OPEN VAULT</button>
            <button className="btn danger" onClick={resetVault}>RESET</button>
          </div>

          <div className="hr" />

          <h2>Alert Policy</h2>
          <div className="small">
            This version is intentionally manual (no spam).  
            When you want alerts, we’ll add a local notifier and a daily scan schedule for server deployments.
          </div>
        </div>
      </div>

      {vaultOpen && (
        <div className="modalOverlay" onClick={() => setVaultOpen(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modalHeader">
              <h3>API Vault</h3>
              <button className="btn" onClick={() => setVaultOpen(false)}>Close</button>
            </div>
            <div className="small" style={{marginTop:6}}>
              Recommended: store keys as Vercel environment variables for real deployments.  
              For personal use, you can store them locally in this browser (Vault).
            </div>

            <div className="hr" />

            <div className="form">
              <div className="full">
                <div className="label">Amadeus Environment</div>
                <select className="select" value={vault.amadeusEnv} onChange={(e) => setVault(v => ({...v, amadeusEnv: e.target.value as any}))}>
                  <option value="test">Sandbox (test)</option>
                  <option value="prod">Production (prod)</option>
                </select>
              </div>
              <div>
                <div className="label">Amadeus Client ID</div>
                <input className="input" value={vault.amadeusClientId} onChange={(e) => setVault(v => ({...v, amadeusClientId: e.target.value.trim()}))} placeholder="client_id" />
              </div>
              <div>
                <div className="label">Amadeus Client Secret</div>
                <input className="input" value={vault.amadeusClientSecret} onChange={(e) => setVault(v => ({...v, amadeusClientSecret: e.target.value.trim()}))} placeholder="client_secret" />
              </div>

              <div className="full">
                <div className="label">Rare / Private APIs (JSON placeholder)</div>
                <textarea className="input" style={{minHeight:120}} value={vault.rareApisJson} onChange={(e) => setVault(v => ({...v, rareApisJson: e.target.value}))}
                  placeholder='{"name":"SomeRareAPI","baseUrl":"https://...","key":"..."}' />
                <div className="small">Stored locally only. This is a placeholder to keep the architecture open for “rare APIs”.</div>
              </div>
            </div>

            <div className="hr" />

            <div className="row">
              <button className="btn" onClick={saveVault}>SAVE</button>
              <button className="btn primary" onClick={testConnection} disabled={loading || !vault.amadeusClientId || !vault.amadeusClientSecret}>TEST CONNECTION</button>
              <button className="btn" onClick={() => { saveVault(); setVaultOpen(false); setStatus(activated ? "Activated." : "Vault saved. Insert keys to activate."); }}>
                ACTIVATE
              </button>
            </div>

            <div className="small" style={{marginTop:10}}>
              If you later commercialize: move Vault storage to server-side secrets (Vercel env vars) and implement user auth.  
              Right now: single-user private tool.
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
