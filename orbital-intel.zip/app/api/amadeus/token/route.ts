import { NextResponse } from "next/server";

function baseUrl(env: "test" | "prod") {
  return env === "prod" ? "https://api.amadeus.com" : "https://test.api.amadeus.com";
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const env = (body.env === "prod" ? "prod" : "test") as "test" | "prod";
    const clientId = (body.clientId || process.env.AMADEUS_CLIENT_ID || "").toString().trim();
    const clientSecret = (body.clientSecret || process.env.AMADEUS_CLIENT_SECRET || "").toString().trim();

    if (!clientId || !clientSecret) {
      return NextResponse.json({ error: "Missing Amadeus clientId/clientSecret" }, { status: 400 });
    }

    const url = `${baseUrl(env)}/v1/security/oauth2/token`;
    const form = new URLSearchParams();
    form.set("grant_type", "client_credentials");
    form.set("client_id", clientId);
    form.set("client_secret", clientSecret);

    const r = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: form.toString(),
      cache: "no-store",
    });

    const data = await r.json();
    if (!r.ok) {
      return NextResponse.json({ error: data?.error_description || data?.error || "Amadeus token failed", details: data }, { status: 400 });
    }

    return NextResponse.json({
      access_token: data.access_token,
      expires_in: data.expires_in,
      token_type: data.token_type,
    });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Unknown error" }, { status: 500 });
  }
}
