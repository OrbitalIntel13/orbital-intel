import { NextResponse } from "next/server";

function baseUrl(env: "test" | "prod") {
  return env === "prod" ? "https://api.amadeus.com" : "https://test.api.amadeus.com";
}

type Cabin = "ECONOMY" | "PREMIUM_ECONOMY" | "BUSINESS";

async function getToken(env: "test" | "prod", clientId: string, clientSecret: string) {
  const url = `${baseUrl(env)}/v1/security/oauth2/token`;
  const form = new URLSearchParams();
  form.set("grant_type", "client_credentials");
  form.set("client_id", clientId);
  form.set("client_secret", clientSecret);

  const r = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: form.toString(),
    cache: "no-store",
  });

  const data = await r.json();
  if (!r.ok) throw new Error(data?.error_description || data?.error || "Token failed");
  return data.access_token as string;
}

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const env = (body.env === "prod" ? "prod" : "test") as "test" | "prod";
    const clientId = (body.clientId || process.env.AMADEUS_CLIENT_ID || "").toString().trim();
    const clientSecret = (body.clientSecret || process.env.AMADEUS_CLIENT_SECRET || "").toString().trim();

    if (!clientId || !clientSecret) {
      return NextResponse.json({ error: "Missing Amadeus clientId/clientSecret" }, { status: 400 });
    }

    const origin = (body.origin || "").toString().trim().toUpperCase();
    const destination = (body.destination || "").toString().trim().toUpperCase();
    const departDate = (body.departDate || "").toString().trim();
    const returnDate = (body.returnDate || "").toString().trim();
    const travelClass = (body.cabin || "ECONOMY") as Cabin;
    const adults = Number(body.adults || 1);
    const max = Number(body.max || 20);
    const nonStop = Boolean(body.nonStop || false);

    if (!origin || !destination || !departDate) {
      return NextResponse.json({ error: "Missing required params: origin, destination, departDate" }, { status: 400 });
    }

    const token = await getToken(env, clientId, clientSecret);

    const url = new URL(`${baseUrl(env)}/v2/shopping/flight-offers`);
    url.searchParams.set("originLocationCode", origin);
    url.searchParams.set("destinationLocationCode", destination);
    url.searchParams.set("departureDate", departDate);
    if (returnDate) url.searchParams.set("returnDate", returnDate);
    url.searchParams.set("adults", String(adults));
    url.searchParams.set("travelClass", travelClass);
    url.searchParams.set("max", String(max));
    if (nonStop) url.searchParams.set("nonStop", "true");
    url.searchParams.set("currencyCode", "EUR");

    const r = await fetch(url.toString(), {
      headers: { Authorization: `Bearer ${token}` },
      cache: "no-store",
    });

    const data = await r.json();
    if (!r.ok) {
      return NextResponse.json({ error: data?.errors?.[0]?.detail || "Flight offers failed", details: data }, { status: 400 });
    }

    const offers = (data.data || []).map((o: any) => {
      const priceTotal = Number(o?.price?.total || 0);
      const currency = o?.price?.currency || "EUR";
      const carrierCodes = new Set<string>();
      let nonStopDetected = true;

      const itineraries = o?.itineraries || [];
      for (const it of itineraries) {
        const segs = it?.segments || [];
        if (segs.length > 1) nonStopDetected = false;
        for (const s of segs) {
          if (s?.carrierCode) carrierCodes.add(s.carrierCode);
        }
      }

      return {
        id: o?.id,
        total: priceTotal,
        currency,
        airlineCodes: Array.from(carrierCodes),
        nonStop: nonStopDetected,
      };
    });

    return NextResponse.json({ offers });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Unknown error" }, { status: 500 });
  }
}
