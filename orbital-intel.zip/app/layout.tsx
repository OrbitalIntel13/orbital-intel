import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "ORBITAL INTEL",
  description: "Private flight intelligence system",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        {children}
      </body>
    </html>
  );
}
